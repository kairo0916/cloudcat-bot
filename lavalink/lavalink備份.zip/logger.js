const os = require('os');

// ANSI 顏色定義
const COLORS = {
  DEBUG: '\x1b[35m',   // 紫色
  INFO: '\x1b[34m',    // 藍色
  WARN: '\x1b[33m',    // 黃色
  ERROR: '\x1b[31m',   // 紅色
  SUCCESS: '\x1b[32m', // 綠色
  RESET: '\x1b[0m'     // 重置
};

function formatTime() {
  const now = new Date();
  return `${String(now.getMonth() + 1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
}

function baseLog({ level = 'INFO', emoji = '🎵', title = '系統訊息', guild, user, node, details }) {
  const color = COLORS[level] || COLORS.INFO;
  const timeStr = `[${formatTime()}]`;
  
  // 標題行
  let output = `${color}${timeStr} ${emoji} [${level}] ${title}${COLORS.RESET}\n`;

  // 資訊區塊
  if (guild) output += `[伺服器] ${guild}\n`;
  if (user) output += `[使用者] ${user}\n`;
  if (node) output += `[Node] ${node}\n`;

  // 內容細節
  if (details) {
    if (guild || user || node) output += '\n'; // 為了排版美觀加空行
    output += `${details}\n`;
  }

  // 分隔線
  output += '----------------------------------------';
  console.log(output);
}

// 導出不同等級的快捷函式
module.exports = {
  debug: (opt) => baseLog({ ...opt, level: 'DEBUG', emoji: opt.emoji || '🐛' }),
  info: (opt) => baseLog({ ...opt, level: 'INFO', emoji: opt.emoji || '🎵' }),
  warn: (opt) => baseLog({ ...opt, level: 'WARN', emoji: opt.emoji || '⚠️' }),
  error: (opt) => baseLog({ ...opt, level: 'ERROR', emoji: opt.emoji || '❌' }),
  success: (opt) => baseLog({ ...opt, level: 'SUCCESS', emoji: opt.emoji || '✅' }),
  
  // 提供一個獲取系統資源的輔助函數 (用於📊統計)
  getSystemStats: () => {
    const memoryUsage = process.memoryUsage();
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMemMb = (memoryUsage.rss / 1024 / 1024).toFixed(2);
    
    const uptimeSecs = process.uptime();
    const days = Math.floor(uptimeSecs / 86400);
    const hours = Math.floor((uptimeSecs % 86400) / 3600);
    
    return {
      memoryStr: `${usedMemMb}MB / ${(totalMem / 1024 / 1024 / 1024).toFixed(1)}GB`,
      uptimeStr: `${days}d ${hours}h`,
      // CPU 佔用率需要更複雜的計算，這邊先給基本系統附載
      cpuStr: `${os.loadavg()[0].toFixed(2)}%` 
    };
  }
};